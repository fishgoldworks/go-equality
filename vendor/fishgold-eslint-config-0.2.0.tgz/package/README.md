# Shared ESLint and Prettier Configuration

This package implements the Engineering Playbook's JavaScript defaults. Choose the exports matching the consumer's languages and environments. It is separately packable, not installed or executed by the documentation importer. Equivalent tooling may enforce the same conventions.

## Compatibility and installation

Package 0.2 uses ESLint 10 with compatible import, React and accessibility plugins. The authoring lock tests ESLint 10.11.0. Install compatible peers normally; do not use forced installation, legacy peer resolution or overrides to hide incompatibility. Existing consumers must review framework/plugin compatibility before upgrading their ESLint major. Equivalent maintained tooling can enforce the same conventions.

Package engines require Node 22.18 or newer within Node 22, or Node 24 and newer; ESLint 10 does not support Node 23. The React and TypeScript plugins are optional peers and load only from their respective subpaths. This package is private to prevent accidental registry publication. Publication and consumer rollout are separate actions.

Until a registry release is approved, build an artifact from an immutable playbook tag:

1. Check out the chosen immutable tag in a clean checkout and record its resolved commit.
2. Run `npm ci --ignore-scripts` and `npm run verify` at the repository root.
3. Run `npm pack --workspace @fishgold/eslint-config --pack-destination <artifact-directory>`.
4. Vendor the resulting tarball in the consumer, record the playbook tag, commit, package version and artifact SHA-256 in application-owned dependency documentation, and install its local path with the consumer's package manager. Commit the tarball and dependency lock. Never pack a dirty checkout for distribution or depend on a floating branch or an absolute author-machine path.

Install exact development-tool versions and commit the generated lock:

```sh
npm install --save-dev --save-exact eslint@10.11.0 prettier@3.9.6
# Only when selecting the React export:
npm install --save-dev --save-exact @eslint-react/eslint-plugin@5.20.8 eslint-plugin-react-hooks@7.1.1 eslint-plugin-jsx-a11y-x@0.2.0 typescript@6.0.3
# Only when selecting the TypeScript export:
npm install --save-dev --save-exact typescript@6.0.3 typescript-eslint@8.70.1
```

Keep a compatible existing TypeScript version where possible (TypeScript 5 through 6.0). The React plugin itself requires the TypeScript package, including when linting JavaScript; selecting React does not require a tsconfig, typed linting or the TypeScript export. The base JavaScript export needs neither TypeScript nor React. Projects own their React, framework, runtime and test-runner versions. Review dependency and preset changes before updating the lock.

### Migrating from package 0.1

The [ESLint 10 migration guide](https://eslint.org/docs/latest/use/migrate-to-10.0.0) covers runtime/API changes and config lookup from each linted file's directory. Check CLI discovery in monorepos. Update scoped overrides and inline disables: import rule/settings prefixes change from `import/` to `import-x/`, accessibility prefixes and component settings change from `jsx-a11y` to `jsx-a11y-x`, and React rules now use explicit `@eslint-react/` names. React rules are not a prefix-only rename; inspect this package's React export and the [new rule catalog](https://eslint-react.xyz/docs/rules). Remove obsolete plugin dependencies only after checking other presets that consume them.

The maintained replacements are [eslint-plugin-import-x](https://github.com/un-ts/eslint-plugin-import-x), [ESLint React](https://github.com/Rel1cx/eslint-react) and [eslint-plugin-jsx-a11y-x](https://github.com/es-tooling/eslint-plugin-jsx-a11y-x). ESLint 10 handles JSX variable references directly. A small `playbook/no-duplicate-jsx-props` rule retains duplicate explicit-prop detection in JavaScript, which the new React plugin delegates to editors/compilers. It does not infer the contents of spreads or autofix potentially side-effectful expressions.

Unused-expression checks now include JSX in JavaScript and TypeScript, catching a discarded JSX element when a return is accidentally omitted. The previous `react/require-render-return`, `react/no-string-refs` and `react/no-is-mounted` rules are not included: [current React accepts `undefined` as an empty render result](https://react.dev/reference/react/Component#render), and deprecated class-API coverage differs between plugins. Consumers that need those legacy checks must add a compatible scoped check and verify it during migration. This is a reviewed baseline, not a one-for-one legacy preset replacement; keep compiler, framework and behavior checks.

## JavaScript configuration

Create `eslint.config.mjs` in the consumer. All globs below are consumer-owned examples, not prescribed directories:

```js
import { javascript } from '@fishgold/eslint-config';
import { browser, node } from '@fishgold/eslint-config/environments';
import { tests } from '@fishgold/eslint-config/tests';

export default [
  { ignores: ['dist/**', 'coverage/**', 'docs/playbook/**'] },
  ...javascript(),
  browser({ files: ['src/**'] }),
  node({ files: ['server/**', 'scripts/**', '*.config.mjs', 'test/**'] }),
  node({ files: ['**/*.cjs'], commonjs: true }),
  ...tests({ runner: 'node' })
];
```

Use `commonjs: true` for `.js` files in a CommonJS package too; `.js` otherwise follows the flat config's module default. Node ESM uses Node builtin globals without injecting CommonJS `require`, `module` or `__dirname`. Browser globals, Node globals and runner globals are separate: do not apply them all to every file. Browser tests may need browser globals as well as their runner globals. Add maintained config/scripts, stories and server files to the applicable scopes; ignore only actual generated/vendor output.

`javascript({ files, devFiles })` accepts replacement glob lists. Its defaults cover JS/JSX/MJS/CJS; development scopes include tests, stories, mocks, Storybook, config/setup modules and scripts. If providing `devFiles`, include every intended development scope. ESLint resolves file globs relative to the consumer config; keep monorepo package scopes explicit.

## React, TypeScript and framework configuration

Add selected exports to the same array:

```js
import { react } from '@fishgold/eslint-config/react';
import { typescript } from '@fishgold/eslint-config/typescript';

// Inside the exported config array, after javascript():
// ...typescript({ tsconfigRootDir: import.meta.dirname }),
// ...react(),
```

`typescript({ tsconfigRootDir, files, devFiles, project })` includes the JavaScript baseline for TS/TSX/MTS/CTS and recommended type-checked rules. `tsconfigRootDir` is required and absolute. The TypeScript project service uses the real projects covering each selected file; `project` selects the resolver's tsconfig (default `./tsconfig.json`, relative to that root). For monorepos, configure one scoped entry per package. Include maintained TS configs/tests in a suitable project or give their explicit scope an appropriate untyped configuration; do not silently ignore them or disable typed rules globally to hide project errors. `void promise` alone does not satisfy failure handling. Continue running the real compiler separately.

`react({ files })` covers JS and TS by default so Hooks in non-JSX modules are checked. It supports the automatic JSX runtime, selected React correctness rules, recommended accessibility checks and the two foundational Hooks rules. The explicit React selection checks keys, nested component definitions, direct state mutation and unsafe DOM usage; it does not mandate function components, React 19 API migrations or every new compiler diagnostic. PropTypes are not required: enforce typed props with the selected type system and actual runtime boundary validation. Configure custom component/attribute mappings in `settings['jsx-a11y-x']` for the UI library used by the application. Set `settings['react-x'].version` explicitly when automatic React detection does not match the consuming package, especially in monorepos. Preserve accessible semantics and keyboard behavior; lint cannot prove all accessibility requirements.

Add the framework's compatible official rules and Storybook's scoped recommended configuration when those tools are present. Check the entire preset dependency chain: a framework bundle that includes old React/accessibility plugins may not support ESLint 10 even if its framework-specific plugin does. Do not append an incompatible bundle or disable its checks to force adoption. Keep framework discovery names, server/client boundaries and generated types intact. These presets do not replace framework lint/build checks or install framework packages.

## Imports and naming

The base checks resolution, casing, duplicates, cycles, self-imports and runtime imports from undeclared or development-only packages. Its resolver understands package exports and JS/TS config paths without requiring the TypeScript compiler. The TypeScript export resolves aliases from the selected tsconfig. JS aliases need resolver settings aligned with the consumer's compiler/bundler. Resolution is not proof of runtime availability: retain build/package checks, particularly for types-only packages and conditional exports. For applications adopting aliases, add `no-restricted-imports` patterns for parent-relative paths and deliberate exceptions in the actual application scope. Preserve the baseline's development-import restrictions when overriding that rule.

Production files cannot statically import/re-export conventionally named test/story modules; CommonJS literal imports are also guarded. This is a partial boundary check: alias-hidden destinations, dynamic imports, unusual barrel layouts and emitted declarations need the application's graph/build/package checks. Type-only package imports are not treated as runtime dependencies. Check public declaration consumers separately. Filename-to-symbol identity and exact companion naming also need owner-aware enforcement; these presets do not claim to infer those contracts from filename patterns alone.

## Formatting and validation

Create `prettier.config.mjs`:

```js
export { default } from '@fishgold/eslint-config/prettier';
```

This selects single JS/TS quotes with escape reduction, double JSX quotes, no optional trailing commas, semicolons, two spaces, a 120-column target, LF, and parentheses around arrow parameters. JSON keeps required double quotes. Syntax-required TSX generic commas remain. Prettier handles final newlines and trailing whitespace. Use `.editorconfig` with the same whitespace choices. Install optional formatter plugins only for stacks needing them; keep them compatible with the selected formatter.

Use one formatter owner. The base disables overlapping ESLint formatting rules, then deliberately restores `curly: ['error', 'all']`, which is compatible with Prettier. Do not reintroduce a trailing-comma/quotes/semi rule or append a preset that silently changes these choices. Verify effective config after adding framework presets.

Add scripts using the repository's package manager:

```json
{
  "lint": "eslint . --max-warnings=0",
  "lint:fix": "eslint . --fix",
  "format": "prettier . --write",
  "format:check": "prettier . --check"
}
```

Define `.prettierignore` and ESLint ignores for generated imports, vendored artifacts and build output; never ignore maintained files simply to make validation pass. Compose `format:check` and `lint` into the consumer's existing validation command alongside relevant types/tests/build. Pin installation through the lockfile, run the same commands in CI, and configure required status checks in repository settings. A config file or local hook alone cannot block merging. Required failures must be fixed or reported as unresolved; do not declare completion, weaken rules or skip checks to pass.

`tests({ files, runner })` supports `node` (import test APIs), `jest` and `vitest` globals, and rejects common `.only` forms. Keep runner-native focused-test safeguards too; aliases and options such as Node's `{ only: true }` are outside this plugin's complete detection contract. Preserve deliberate skipped tests and use the real runner for behavioral validation.

## Adoption and exceptions

Migrate a coherent scope, review autofix diffs, and run relevant behavior/build checks. Keep mass formatting separate from feature changes. Document exceptions by rule, files, reason, owner, compensating checks and review/removal condition. Equivalent maintained tooling is allowed. Avoid copying the full rule catalog into agent instructions: route to the standard and executable configuration, and run the checks.

## Maintainer validation

From the playbook root, run `npm run test:quality`, `npm run check:quality`, and the full `npm run verify`. Behavioral tests cover valid/invalid examples, formatter convergence, JS/CommonJS environments, React, typed aliases/promises and production import boundaries. Validate the packed artifact in a clean external consumer before releasing; package contents exclude tests and authoring-only configuration.
