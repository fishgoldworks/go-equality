import tseslint from 'typescript-eslint';
import path from 'node:path';
import { createRequire } from 'node:module';
import { javascript, typescriptFiles, developmentFiles, typescriptResolverPath } from './javascript.mjs';

const requireFromTypescriptEslint = createRequire(
  createRequire(import.meta.url).resolve('typescript-eslint/package.json')
);
const typescriptParserPath = requireFromTypescriptEslint.resolve('@typescript-eslint/parser');

export function typescript({
  tsconfigRootDir,
  files = typescriptFiles,
  devFiles = developmentFiles,
  project = './tsconfig.json'
}) {
  if (!tsconfigRootDir || !path.isAbsolute(tsconfigRootDir)) {
    throw new TypeError('typescript() requires an absolute consuming project tsconfigRootDir.');
  }
  return tseslint.config({
    name: 'playbook/typescript',
    files,
    extends: [...javascript({ files, devFiles }), ...tseslint.configs.recommendedTypeChecked],
    languageOptions: { parserOptions: { projectService: true, tsconfigRootDir } },
    settings: {
      'import-x/parsers': { [typescriptParserPath]: ['.ts', '.tsx', '.mts', '.cts'] },
      'import-x/resolver': { [typescriptResolverPath]: { project: path.resolve(tsconfigRootDir, project) } }
    },
    rules: {
      'no-undef': 'off',
      'no-unused-vars': 'off',
      'no-unused-expressions': 'off',
      'no-throw-literal': 'off',
      '@typescript-eslint/no-unused-vars': ['error', { args: 'all', argsIgnorePattern: '^_', caughtErrors: 'all' }],
      '@typescript-eslint/no-unused-expressions': ['error', { enforceForJSX: true }],
      '@typescript-eslint/no-floating-promises': ['error', { ignoreVoid: false }],
      '@typescript-eslint/no-misused-promises': 'error',
      '@typescript-eslint/await-thenable': 'error',
      '@typescript-eslint/only-throw-error': 'error'
    }
  });
}
