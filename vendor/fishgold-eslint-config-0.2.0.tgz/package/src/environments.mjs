import globals from 'globals';

function requireFiles(files) {
  if (!Array.isArray(files) || files.length === 0 || files.some((file) => typeof file !== 'string' || !file.trim())) {
    throw new TypeError('Environment files must be a nonempty list of explicit globs.');
  }
}

export function browser({ files } = {}) {
  requireFiles(files);
  return { name: 'playbook/browser', files, languageOptions: { globals: globals.browser } };
}

export function node({ files, commonjs = false } = {}) {
  requireFiles(files);
  return {
    name: 'playbook/node',
    files,
    languageOptions: {
      globals: commonjs ? globals.node : globals.nodeBuiltin,
      ...(commonjs ? { sourceType: 'commonjs' } : {})
    }
  };
}
