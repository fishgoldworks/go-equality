const noDuplicateJsxProps = {
  meta: {
    type: 'problem',
    docs: { description: 'Reject duplicate explicit JSX props, including in plain JavaScript.' },
    schema: [],
    messages: { duplicate: 'Duplicate JSX prop "{{name}}".' }
  },
  create(context) {
    return {
      JSXOpeningElement(element) {
        const names = new Set();
        for (const attribute of element.attributes) {
          if (attribute.type !== 'JSXAttribute') {
            continue;
          }
          const name =
            attribute.name.type === 'JSXIdentifier'
              ? attribute.name.name
              : `${attribute.name.namespace.name}:${attribute.name.name.name}`;
          if (names.has(name)) {
            context.report({ node: attribute, messageId: 'duplicate', data: { name } });
          }
          names.add(name);
        }
      }
    };
  }
};

export default noDuplicateJsxProps;
