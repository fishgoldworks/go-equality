import reactPlugin from '@eslint-react/eslint-plugin';
import hooks from 'eslint-plugin-react-hooks';
import accessibility from 'eslint-plugin-jsx-a11y-x';
import { javascriptFiles, typescriptFiles } from './javascript.mjs';
import noDuplicateJsxProps from './noDuplicateJsxProps.mjs';

const playbook = { rules: { 'no-duplicate-jsx-props': noDuplicateJsxProps } };

export function react({ files = [...javascriptFiles, ...typescriptFiles] } = {}) {
  return [
    {
      name: 'playbook/react',
      files,
      languageOptions: { parserOptions: { ecmaFeatures: { jsx: true } } },
      plugins: { '@eslint-react': reactPlugin, 'react-hooks': hooks, 'jsx-a11y-x': accessibility, playbook },
      rules: {
        ...accessibility.configs.recommended.rules,
        'playbook/no-duplicate-jsx-props': 'error',
        '@eslint-react/no-missing-key': 'error',
        '@eslint-react/no-duplicate-key': 'error',
        '@eslint-react/no-missing-component-display-name': 'error',
        '@eslint-react/no-nested-component-definitions': 'error',
        '@eslint-react/no-direct-mutation-state': 'error',
        '@eslint-react/no-component-will-mount': 'error',
        '@eslint-react/no-component-will-receive-props': 'error',
        '@eslint-react/no-component-will-update': 'error',
        '@eslint-react/jsx-no-children-prop': 'error',
        '@eslint-react/jsx-no-comment-textnodes': 'error',
        '@eslint-react/jsx-no-useless-fragment': 'error',
        '@eslint-react/dom-no-dangerously-set-innerhtml-with-children': 'error',
        '@eslint-react/dom-no-find-dom-node': 'error',
        '@eslint-react/dom-no-render-return-value': 'error',
        '@eslint-react/dom-no-string-style-prop': 'error',
        '@eslint-react/dom-no-unknown-property': 'error',
        '@eslint-react/dom-no-unsafe-target-blank': 'error',
        'react-hooks/rules-of-hooks': 'error',
        'react-hooks/exhaustive-deps': 'error'
      }
    }
  ];
}
