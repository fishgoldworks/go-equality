export default {
  trailingComma: 'none',
  tabWidth: 2,
  useTabs: false,
  semi: true,
  singleQuote: true,
  jsxSingleQuote: false,
  printWidth: 120,
  endOfLine: 'lf',
  arrowParens: 'always'
};
