import js from '@eslint/js';
import prettier from 'eslint-config-prettier/flat';
import imports from 'eslint-plugin-import-x';
import { createRequire } from 'node:module';

export const typescriptResolverPath = createRequire(import.meta.url).resolve('eslint-import-resolver-typescript');

export const javascriptFiles = ['**/*.{js,jsx,mjs,cjs}'];
export const typescriptFiles = ['**/*.{ts,tsx,mts,cts}'];
export const developmentFiles = [
  '**/*.{test,spec,stories}.*',
  '**/{test,tests,__tests__,__mocks__,.storybook}/**',
  '**/*.{config,setup}.{js,cjs,mjs,ts,cts,mts}',
  '**/scripts/**'
];

const developmentImports = [
  '**/*.test',
  '**/*.spec',
  '**/*.stories',
  '**/*.test.*',
  '**/*.spec.*',
  '**/*.stories.*',
  '**/test/**',
  '**/tests/**',
  '**/__tests__/**',
  '**/__mocks__/**',
  '**/.storybook/**'
];

export function javascript({ files = javascriptFiles, devFiles = developmentFiles } = {}) {
  return [
    { ...prettier, name: 'playbook/formatter-compatibility', files },
    {
      name: 'playbook/javascript',
      files,
      languageOptions: { ecmaVersion: 'latest', parserOptions: { ecmaFeatures: { jsx: true } } },
      linterOptions: { reportUnusedDisableDirectives: 'error' },
      plugins: { 'import-x': imports },
      // Handles package exports as well as JS/TS paths without requiring the TS compiler.
      settings: {
        'import-x/extensions': ['.js', '.jsx', '.mjs', '.cjs', '.ts', '.tsx', '.mts', '.cts'],
        'import-x/resolver': { [typescriptResolverPath]: { alwaysTryTypes: false } }
      },
      rules: {
        ...js.configs.recommended.rules,
        'no-undef': ['error', { typeof: true }],
        'no-unused-vars': ['error', { args: 'all', argsIgnorePattern: '^_', caughtErrors: 'all' }],
        'no-unused-expressions': ['error', { enforceForJSX: true }],
        'no-var': 'error',
        'prefer-const': 'error',
        curly: ['error', 'all'],
        eqeqeq: ['error', 'always', { null: 'ignore' }],
        'no-eval': 'error',
        'no-implied-eval': 'error',
        'no-new-func': 'error',
        'no-throw-literal': 'error',
        'import-x/no-unresolved': ['error', { commonjs: true, caseSensitive: true, caseSensitiveStrict: true }],
        'import-x/no-duplicates': 'error',
        'import-x/no-cycle': 'error',
        'import-x/no-self-import': 'error',
        'import-x/no-extraneous-dependencies': ['error', { devDependencies: devFiles }]
      }
    },
    {
      name: 'playbook/production-imports',
      files,
      ignores: devFiles,
      rules: {
        'no-restricted-imports': [
          'error',
          {
            patterns: [{ group: developmentImports, message: 'Keep production contracts with their production owner.' }]
          }
        ],
        'no-restricted-modules': ['error', { patterns: developmentImports }]
      }
    }
  ];
}
