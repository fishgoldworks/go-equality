import globals from 'globals';
import noOnlyTests from 'eslint-plugin-no-only-tests';

const testFiles = ['**/*.{test,spec}.*', '**/{test,tests,__tests__}/**'];
const runnerGlobals = {
  node: {},
  jest: globals.jest,
  vitest: Object.fromEntries(
    [
      'suite',
      'test',
      'describe',
      'it',
      'expect',
      'assert',
      'vi',
      'vitest',
      'beforeAll',
      'afterAll',
      'beforeEach',
      'afterEach',
      'onTestFailed',
      'onTestFinished'
    ].map((name) => [name, 'readonly'])
  )
};

export function tests({ files = testFiles, runner = 'node' } = {}) {
  if (!Object.hasOwn(runnerGlobals, runner)) {
    throw new TypeError(`Unsupported test runner: ${runner}`);
  }
  return [
    {
      name: 'playbook/tests',
      files,
      languageOptions: { globals: runnerGlobals[runner] },
      plugins: { 'no-only-tests': noOnlyTests },
      rules: {
        'no-only-tests/no-only-tests': [
          'error',
          { block: ['describe', 'it', 'test', 'suite'], functions: ['fit', 'fdescribe'] }
        ]
      }
    }
  ];
}
